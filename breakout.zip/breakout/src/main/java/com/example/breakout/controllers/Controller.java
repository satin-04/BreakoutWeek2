package com.example.breakout.controllers;

import com.example.breakout.objects.BreakOutObject;

public abstract class Controller
{
    abstract void doFrameLogic();
}
