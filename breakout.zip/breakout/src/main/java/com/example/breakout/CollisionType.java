package com.example.breakout;

public enum CollisionType
{
    NoCollision,
    TopImpact,
    BottomImpact,
    LeftImpact,
    RightImpact
}
